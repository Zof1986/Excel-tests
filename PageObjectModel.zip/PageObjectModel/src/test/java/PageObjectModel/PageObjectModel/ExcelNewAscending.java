package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class ExcelNewAscending {

	 public boolean areColumnValuesAscending(String filePath) throws IOException {
	        FileInputStream fis = null;
	        boolean col3Ascending = true;
	        int previousCol3Value = Integer.MIN_VALUE; // Initialize with the smallest possible integer
	        Set<String> uniqueValues = new HashSet<>(); // To track unique values in column K

	        try {
	            fis = new FileInputStream(new File(filePath));
	            Workbook workbook = WorkbookFactory.create(fis);
	            Sheet sheet = workbook.getSheetAt(0); // Access the first sheet

	            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) { // Start from row 1 to skip header
	                Row row = sheet.getRow(rowIndex);

	                if (row != null) {
	                    // Read column 3 (index 2)
	                    Cell col3Cell = row.getCell(2);
	                    // Read column K (index 10)
	                    Cell colKCell = row.getCell(10);

	                    if (colKCell != null) {
	                        uniqueValues.add(colKCell.toString().trim());
	                    }

	                    if (colKCell != null && uniqueValues.equals(colKCell.toString().trim())) {
	                        // Check if the cell has a numeric value
	                        if (col3Cell != null && col3Cell.getCellType() == CellType.NUMERIC) {
	                            int col3Value = (int) col3Cell.getNumericCellValue();

	                            // Check if the value is ascending (greater than the previous value)
	                            if (col3Value < previousCol3Value) {
	                                col3Ascending = false; // Set flag to false if not ascending
	                                System.out.println("Row " + (rowIndex + 1) + " is not in ascending order. Value: " + col3Cell.getNumericCellValue());
	                                break; // Exit loop once we find the order is not ascending
	                            }

	                            // Update the previous value
	                            previousCol3Value = col3Value;
	                        }
	                    }
	                }
	            }
	        } finally {
	            if (fis != null) {
	                fis.close(); // Ensure the file input stream is closed
	            }
	        }

	        return col3Ascending;
	    }
}
