package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ExcelTransactionValidator {

	  private final String filePath;
	    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd"); // Adjust format if needed

	    public ExcelTransactionValidator(String filePath) {
	        this.filePath = filePath;
	    }

	    public List<String> validateTransactionDates() throws IOException {
	        List<String> errorDetails = new ArrayList<>();
	        Map<String, Date> bind1Dates = new HashMap<>();

	        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
	            Workbook workbook = WorkbookFactory.create(fis);
	            Sheet sheet = workbook.getSheetAt(0);

	            for (Row row : sheet) {
	                Cell columnK = row.getCell(10); // Column K
	                Cell columnL = row.getCell(11); // Column L
	                Cell columnM = row.getCell(12); // Column M

	                // Get values from the cells
	                String valueKK = columnK != null ? columnK.toString().trim() : null;
	                String valueLL = columnL != null ? columnL.toString().trim() : null;
	                String valueMM = columnM != null ? columnM.toString().trim() : null;

	                if (valueKK != null && valueLL != null && valueMM != null) {
	                    try {
	                        Date date = dateFormat.parse(valueMM);

	                        // Store dates for "IN", "END", "CAN", "REI"
	                        if ("IN".equals(valueLL) || "END".equals(valueLL) || "CAN".equals(valueLL) || "REI".equals(valueLL)) {
	                            bind1Dates.put(valueLL, date);
	                        }
	                    } catch (ParseException e) {
	                        errorDetails.add("Row " + (row.getRowNum() + 1) + ": Invalid date format in column M for '" + valueLL + "'. Value: " + valueMM);
	                    }
	                }
	            }

	            // Validate "IN" and "END" dates
	            if (bind1Dates.containsKey("IN") && bind1Dates.containsKey("END")) {
	                Date inDate = bind1Dates.get("IN");
	                Date endDate = bind1Dates.get("END");

	                if (endDate.before(inDate)) {
	                    errorDetails.add("Validation failed: 'END' date (" + dateFormat.format(endDate) + ") is before 'IN' date (" + dateFormat.format(inDate) + ").");
	                }
	            }

	            // Validate "CAN" and "REI" dates
	            if (bind1Dates.containsKey("CAN") && bind1Dates.containsKey("REI")) {
	                Date canDate = bind1Dates.get("CAN");
	                Date reiDate = bind1Dates.get("REI");

	                if (reiDate.before(canDate)) {
	                    errorDetails.add("Validation failed: 'REI' date (" + dateFormat.format(reiDate) + ") is before 'CAN' date (" + dateFormat.format(canDate) + ").");
	                }
	            }
	        }

	        return errorDetails;
	    }
	
}
