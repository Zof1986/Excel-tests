package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.*;

public class ExcelStateValidator {
    public String filePath;

    // Constructor
    public ExcelStateValidator(String filePath) {
        this.filePath = filePath;
    }

    // Method to process the Excel file
    public void processExcel() {
        FileInputStream fis = null;
        FileOutputStream fos = null;
        Workbook workbook = null;

        try {
            fis = new FileInputStream(filePath);
            workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0);

            // Map to store values from Column B based on Column A
            Map<String, Set<String>> dataMap = new HashMap<>();

            // Read data from Excel
            for (Row row : sheet) {
             //   if (row.getRowNum() == 0) continue; // Skip header row if exists

                Cell cellK = row.getCell(10);
                Cell cellN = row.getCell(13);

              //  System.out.println(row.getRowNum()+" "+  cellK +" "+ cellN);
                if (cellK != null && cellN != null) {
                    String key = cellK.getStringCellValue().trim();
                    String value = cellN.getStringCellValue().trim();

                    if (!dataMap.containsKey(key)) {
                        dataMap.put(key, new HashSet<String>());
                    }
                    dataMap.get(key).add(value);
                }
            }

            
            
            
            // Writing results to Column C
            for (Row row : sheet) {
              //  if (row.getRowNum() == 0) continue;

                Cell cellK = row.getCell(10);
                if (cellK == null) continue;

                String key = cellK.getStringCellValue().trim();
                Set<String> values = dataMap.containsKey(key) ? dataMap.get(key) : new HashSet<String>();

                // Create or get Column C cell
                Cell cellO = row.getCell(14);
                if (cellO == null) {
                   cellO = row.createCell(14);
                                  }
                //System.out.println(row.getRowNum() +" "+  cellO);

                // If all Column B values are the same for a given Column A, write "N", else "Y"
                cellO.setCellValue(values.size() == 1 ? "N" : "Y");
            }

            // Save the updated file
            fos = new FileOutputStream(filePath);
            workbook.write(fos);
            System.out.println("Excel file processed successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (workbook != null) workbook.close();
                if (fis != null) fis.close();
                if (fos != null) fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

   }