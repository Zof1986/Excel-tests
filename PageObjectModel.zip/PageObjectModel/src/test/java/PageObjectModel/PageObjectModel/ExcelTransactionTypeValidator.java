package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;


/*
public class ExcelTransationTypeValidator {

	private final String filePath;

    public ExcelTransationTypeValidator(String filePath) {
        this.filePath = filePath;
    }

    public List<String> validateTransactionSheet() throws IOException {
        List<String> errorDetails = new ArrayList<>();
        List<String> expectedOrder = Arrays.asList("IN", "END", "CAN", "REI");
        int expectedIndex = 0;
        boolean isFirstIN = true;
        String lastValueForBind1 = null;

        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                Cell columnK = row.getCell(10); // Column K
                Cell columnL = row.getCell(11); // Column L

                String valueKK = columnK != null ? columnK.toString().trim() : null;
                String valueLL = columnL != null ? columnL.toString().trim() : null;

                if (valueKK != null) {
                    // Check for expected order in Column L
                    if (expectedIndex < expectedOrder.size() && expectedOrder.get(expectedIndex).equals(valueLL)) {
                        expectedIndex++;
                    } else if (expectedIndex < expectedOrder.size()) {
                        errorDetails.add("Row " + (row.getRowNum() + 1) + ": Expected '" + expectedOrder.get(expectedIndex) +
                                "' in Column L, but found '" + valueLL + "'");
                    }

                    // Check if the first "BIND1" contains "IN"
                    if (isFirstIN) {
                        if (!"IN".equals(valueLL)) {
                            errorDetails.add("Row " + (row.getRowNum() + 1) + ": First 'BIND1' row in Column L must contain 'IN', found: " + valueLL);
                        }
                        isFirstIN = false;
                    }

                    // Check if "REI" follows "CAN"
                    if ("REI".equals(valueLL)) {
                        if (!"CAN".equals(lastValueForBind1)) {
                            errorDetails.add("Row " + (row.getRowNum() + 1) + ": 'REI' in Column L must follow 'CAN', but it follows '" + lastValueForBind1 + "'");
                        }
                    }

                    // Update the last value for "BIND1"
                    if (valueLL != null && !valueLL.isEmpty()) {
                        lastValueForBind1 = valueLL;
                    }
                }
            }
        }

        // Check if the entire expected order was matched
        if (expectedIndex != expectedOrder.size()) {
            errorDetails.add("Validation failed: Not all expected values ('IN', 'END', 'CAN', 'REI') were found in the correct order.");
        }

        return errorDetails;
    }
}
*/

public class ExcelTransactionTypeValidator {
    private final String filePath;

    public ExcelTransactionTypeValidator(String filePath) {
        this.filePath = filePath;
    }

    public List<String> validateTransactionSheet() throws IOException {
        List<String> errorDetails = new ArrayList<>();
        List<String> expectedOrder = Arrays.asList("IN", "END", "CAN", "REI");
        int expectedIndex = 0;
        String lastValueForBind1 = null;
        String previousValueK = null; // Keep track of last K column value

        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                Cell columnK = row.getCell(10, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL); // Column K
                Cell columnL = row.getCell(11, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL); // Column L

                String valueK = getCellValue(columnK);
                String valueL = getCellValue(columnL);

                // Check if Column K value changed
                if (valueK != null && !valueK.equals(previousValueK)) {
                    // When Column K changes, Column L must be "IN"
                    if (!"IN".equals(valueL)) {
                        errorDetails.add("Row " + (row.getRowNum() + 1) + ": Column L must be 'IN' when Column K value changes. Found: '" + valueL + "'");
                    }
                }

                // Validate expected order in Column L
                if (expectedIndex < expectedOrder.size() && expectedOrder.get(expectedIndex).equals(valueL)) {
                    expectedIndex++;
                } else if (expectedIndex < expectedOrder.size() && valueL != null) {
                    errorDetails.add("Row " + (row.getRowNum() + 1) + ": Expected '" + expectedOrder.get(expectedIndex) +
                            "' in Column L, but found '" + valueL + "'"); 
                }

                // Ensure "REI" follows "CAN"
                if ("REI".equals(valueL) && !"CAN".equals(lastValueForBind1)) {
                    errorDetails.add("Row " + (row.getRowNum() + 1) + ": 'REI' in Column L must follow 'CAN', but it follows '" + lastValueForBind1 + "'");
                }

                // Update last known values
                if (valueL != null && !valueL.isEmpty()) {
                    lastValueForBind1 = valueL;
                }
                previousValueK = valueK; // Update previous K value
            }
        }

        // Check if the entire expected order was matched
        if (expectedIndex != expectedOrder.size()) {
            errorDetails.add("Validation failed: Not all expected values ('IN', 'END', 'CAN', 'REI') were found in the correct order.");
        }

        return errorDetails;
    }

    // Utility function to get cell value as String
    private String getCellValue(Cell cell) {
        if (cell == null) return null;
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue()).trim();
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue()).trim();
            default:
                return null;
        }
    }
}