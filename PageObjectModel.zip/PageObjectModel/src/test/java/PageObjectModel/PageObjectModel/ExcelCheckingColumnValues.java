package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import org.testng.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class ExcelCheckingColumnValues {

	private Workbook workbook;

    public ExcelCheckingColumnValues(String filePath) throws IOException {
        FileInputStream fis = new FileInputStream(new File(filePath));
        workbook = WorkbookFactory.create(fis);
    }

    public Set<String> getUniqueValuesFromColumn(int sheetIndex, int columnIndex) {
        Set<String> uniqueValues = new HashSet<>();
        Sheet sheet = workbook.getSheetAt(sheetIndex);

        for (Row row : sheet) {
            Cell cell = row.getCell(columnIndex);
            if (cell != null) {
                uniqueValues.add(cell.toString().trim());
            }
        }
        return uniqueValues;
    }

    public void validateData(int sheetIndex, int columnKIndex, int columnFIndex, int columnGIndex) {
        Sheet sheet = workbook.getSheetAt(sheetIndex);
        Set<String> uniqueValues = new HashSet<>();

        for (Row row : sheet) {
            Cell columnK = row.getCell(columnKIndex);

            if (columnK != null) {
                uniqueValues.add(columnK.toString().trim());

                if (uniqueValues.equals(columnK.toString().trim())) {
                    Cell columnF = row.getCell(columnFIndex);
                    Cell columnG = row.getCell(columnGIndex);

                    if (columnF != null && columnG != null) {
                        String valueF = columnF.toString().trim();
                        String valueG = columnG.toString().trim();

                        if (valueF.equals("a")) {
                            Assert.assertEquals(valueG, "b", "Mismatch at Row " + (row.getRowNum() + 1) +
                                    " | Expected Column G: b, but found: " + valueG);
                        }

                        if (valueF.equals("c")) {
                            Assert.assertTrue(valueG.isEmpty(), "Mismatch at Row " + (row.getRowNum() + 1) +
                                    " | Expected Column G to be blank, but found: " + valueG);
                        }
                    }
                }
            }
        }
    }

    public void closeWorkbook() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }
}
