package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ExcelTesting {

	 	WebDriver driver;
	    String downloadPath = "C:/Users/nikol/OneDrive/Radna površina";
	    String downloadedFile = downloadPath + "/noviTest1.1.xlsx";
	    
	   
	    
	    @BeforeTest
	    public void setup() {
	    	WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();	
		
	    }
  
	    @Test
	    public void testNULLvaluesExcelFile() {
	        // Define the file path for the Excel file
	        String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";

	        // Create an instance of the utility class
	        ExcelNULLValues excelUtility = new ExcelNULLValues();

	        try {
	            // Call the method to check for NULL or empty values in the Excel file
	            boolean hasNullValues = excelUtility.checkForNullValues(filePath);

	            // Assert that no NULL or empty values should be found in the file
	            assertFalse(hasNullValues, "Validation failed: NULL or empty values were found.");

	            // Print result
	            if (!hasNullValues) {
	                System.out.println("No NULL or empty values found in the Excel file.");
	            } else {
	                System.out.println("Validation failed: NULL or empty values were found.");
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	            fail("IOException occurred during test execution.");
	        }
	    }
	
	 
	     /*
	     @Test
	     public void columnnames() {
	    	 
	    	 String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";
	    	 FileInputStream fis = null;
		       try {
             // Open the file input stream
             fis = new FileInputStream(new File(filePath));

        //     Sheet sheet = workbook.getSheetAt(0); 
             // Create the workbook from the file
             Workbook workbook = WorkbookFactory.create(fis); {

	             // Access the first sheet
	             Sheet sheet = workbook.getSheetAt(0);

	             // Assuming column names are in the first row
	             Row headerRow = sheet.getRow(5);

	             if (headerRow != null) {
	                 // Iterate through each cell in the header row
	                 for (Cell cell : headerRow) {
	                     System.out.println("Column Name: " + cell.getStringCellValue());
	                 }
	             } else {
	                 System.out.println("No header row found!");
	             }
	         }
             } catch (IOException e) {
	             e.printStackTrace();
	         }
	     
	     }
	     */
	     
	    @Test
	    public void newAscending() {
	    	
	    	  // Define the file path for the Excel file
	        String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";

	        // Create an instance of the utility class
	        ExcelNewAscending excelUtility = new ExcelNewAscending();

	        try {
	            // Call the method to check if column 3 values are in ascending order
	            boolean isAscending = excelUtility.areColumnValuesAscending(filePath);

	            // Assert that the column values should be in ascending order
	            assertTrue(isAscending, "Column 3 is NOT in ascending order!");

	            // Print result
	            if (isAscending) {
	                System.out.println("Column 3 is in ascending order.");
	            } else {
	                System.out.println("Column 3 is NOT in ascending order.");
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	            fail("IOException occurred during test execution.");
	        }
	    }
	    
	     
	     @Test
	    public void newAscendingConsecutiveOrder() {
	    	 
	    	 String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";

	         try {
	             // Initialize ExcelAscendingConsecutiveOrder
	             ExcelAscendingConsecutiveOrder excelUtility = new ExcelAscendingConsecutiveOrder(filePath);

	             // Call validateConsecutiveValues (no need to pass file path here)
	             Map<String, List<String>> errors = excelUtility.validateConsecutiveValues(filePath);

	             // Check if there are errors for any value in column K
	             boolean allConsecutive = true;

	             for (Map.Entry<String, List<String>> entry : errors.entrySet()) {
	                 String colKValue = entry.getKey();
	                 List<String> errorMessages = entry.getValue();

	                 if (!errorMessages.isEmpty()) {
	                     allConsecutive = false;
	                     System.out.println("Errors for " + colKValue + ":");
	                     for (String errorMessage : errorMessages) {
	                         System.out.println(errorMessage);
	                     }
	                 } else {
	                     System.out.println("Column C for " + colKValue + " is in consecutive order.");
	                 }
	             }

	             if (!allConsecutive) {
	                 throw new AssertionError("One or more values in column C are NOT in consecutive order!");
	             }

	         } catch (Exception e) {
	             e.printStackTrace();
	         }
	     }
	    
	     @Test
	     public void checkingcolumnvalues() {
	    	 
	    	 String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";

	         try {
	        	 ExcelCheckingColumnValues excelUtility = new ExcelCheckingColumnValues(filePath);

	             // Example: Fetch unique values from column K (index 10) in the first sheet
	             Set<String> uniqueValues = excelUtility.getUniqueValuesFromColumn(0, 10);
	             System.out.println("Unique values in column K: " + uniqueValues);

	             // Validate data in the first sheet
	             excelUtility.validateData(0, 10, 5, 6);

	             // Close the workbook
	             excelUtility.closeWorkbook();

	         } catch (IOException e) {
	             System.out.println("Error handling the Excel file: " + e.getMessage());
	         }
	     }
	     
	     @Test
	     public void hardcoded() {
	         String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";
	         ExcelHardcodedData validator = new ExcelHardcodedData(filePath);

	         try {
	             // Validate the transaction sheet
	             List<String> errors = validator.validateTransactionSheet();

	             if (!errors.isEmpty()) {
	                 // Print errors and fail the test
	                 System.out.println(String.join("\n", errors));
	                 Assert.fail("Validation failed: " + errors.size() + " issues found.");
	             }
	         } catch (IOException e) {
	             Assert.fail("Error reading the Excel file: " + e.getMessage());
	         }
	     }
	     
	     @Test
	     public void transaction() {
	         String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";
	         ExcelTransactionTypeValidator validator = new ExcelTransactionTypeValidator(filePath);

	         try {
	             List<String> errors = validator.validateTransactionSheet();
	             if (!errors.isEmpty()) {
	                 System.out.println(String.join("\n", errors));
	                 Assert.fail("Validation failed: " + errors.size() + " issues found.");
	             }
	         } catch (IOException e) {
	             Assert.fail("Error reading the Excel file: " + e.getMessage());
	         }
	     }
	      
	     
	     @Test
	     public void transactionDates() {
	         String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";
	         ExcelTransactionValidator validator = new ExcelTransactionValidator(filePath);

	         try {
	             // Perform the validation
	             List<String> errors = validator.validateTransactionDates();

	             // Output errors if any
	             if (!errors.isEmpty()) {
	                 System.out.println(String.join("\n", errors));
	                 Assert.fail("Validation failed: " + errors.size() + " issues found.");
	             }
	         } catch (IOException e) {
	             Assert.fail("Error reading the Excel file: " + e.getMessage());
	         }
	     }
	     
	     @Test
	     public void StatesChecikng() throws IOException {
	    	    	
	    	 String filePath = "C:/Users/nikol/OneDrive/Radna površina/noviTest1.1.xlsx";
	    	    ExcelStateValidator validator = new ExcelStateValidator(filePath);
 	   
	            // Process the file
	          
	            validator.processExcel();

	            // Read the processed file
	           
	            FileInputStream fis = new FileInputStream(filePath);
	            Workbook workbook = new XSSFWorkbook(fis);
	            Sheet sheet = workbook.getSheetAt(0);
          
	            // Validate the expected results in column O (Index 14)
	        //    assertEquals("y", sheet.getRow(1).getCell(14).getStringCellValue()); // Example assertion
	            for (Row row : sheet) {
	                if (row.getRowNum() == 0) continue; // Skip header row if needed

	                Cell cellO = row.getCell(14);
	                if (cellO != null) {
	                    String cellValue = cellO.getStringCellValue();
	                    assertEquals("N", cellValue, "Failed at row: " + row.getRowNum());
	                }
	            }
	          
	     }
	     
	     @Test
	     public void MultyStatesChecikng() throws IOException {
	    	 
	    	 //Ne valja , proveri
	    	 String filePath = "C:/Users/nikol/OneDrive/Radna površina/NewTest2.1.xlsx";
	    	 MultyStatePolicy validator = new MultyStatePolicy(filePath);
 	   
	            // Process the file
	          
	            validator.processExcel();

	            // Read the processed file
	           
	            FileInputStream fis = new FileInputStream(filePath);
	            Workbook workbook = new XSSFWorkbook(fis);
	            Map<String, Map<String, String>> groupedData = validator.getGroupedData();

	            for (Map.Entry<String, Map<String, String>> entry : groupedData.entrySet()) {
	                String columnA = entry.getKey();
	                Map<String, String> bValues = entry.getValue();
	                Set<String> uniqueBValues = new HashSet<>(bValues.keySet());
	                boolean hasDifferentB = uniqueBValues.size() > 1; // True if different B values exist

	                for (Map.Entry<String, String> valueEntry : bValues.entrySet()) {
	                    String valueC = valueEntry.getValue();

	                    if (hasDifferentB) {
	                        Assert.assertEquals(valueC, "Y", "Failed: Expected 'Y' but got '" + valueC + "' for A=" + columnA);
	                    } else {
	                        Assert.assertEquals(valueC, "N", "Failed: Expected 'N' but got '" + valueC + "' for A=" + columnA);
	                    }
	                }
	            }

	            System.out.println("All assertions passed successfully!");
	     }
	     
	     @Test
	     public void testColumnCUnique() throws IOException {
	    	  SoftAssert softAssert = new SoftAssert();
	    	   final String FILE_PATH = "C:/Users/nikol/OneDrive/Radna površina/NewTest3.1.xlsx";
	    	      final String SHEET_NAME = "Sheet1";
	    	    ExcelColumnCColumnB validator = new ExcelColumnCColumnB(FILE_PATH, SHEET_NAME);
	         softAssert.assertTrue(validator.validateColumnCUnique(), " Column C has duplicate values!");
	         softAssert.assertTrue(validator.validateColumnBtoCMapping(), " Column B values are not mapped uniquely in Column C!");
	         softAssert.assertTrue(validator.validateColumnAValuesForColumnB(), " Column B values have invalid Column A values!");
	         
	         softAssert.assertAll();
	     }
	     
	     @Test
	     public void testExcelCalculations() throws IOException {
	    	 
	    	   ExcelColumnSumiraze ExcelSumiraze;
	    	  
	    	  ExcelSumiraze = new ExcelColumnSumiraze("C:/Users/nikol/OneDrive/Radna površina/NewTest3.1.xlsx");
	    	  
	    	  Map<String, Boolean> results = ExcelSumiraze.processExcelData();
	          
	          for (Map.Entry<String, Boolean> entry : results.entrySet()) {
	              System.out.println("Validating: " + entry.getKey() + " -> " + (entry.getValue() ? "PASS" : "FAIL"));
	              Assert.assertTrue(entry.getValue(), "Mismatch for key: " + entry.getKey());
	          }
	     }

	   
	     
}
	         
	        
