package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.poi.ss.usermodel.*;
import java.io.*;
import java.util.*;

public class ExcelAscendingConsecutiveOrder {

	public ExcelAscendingConsecutiveOrder(String filePath) {
		// TODO Auto-generated constructor stub
	}

	public static Map<String, List<String>> validateConsecutiveValues(String filePath) throws IOException {
	        Map<String, List<String>> errorsMap = new HashMap<>(); // To store errors for each Column K value
	        Map<String, Integer> expectedValuesMap = new HashMap<>(); // Tracks expected values for each Column K value

	        FileInputStream fis = null;
	        try {
	            fis = new FileInputStream(new File(filePath));
	            Workbook workbook = WorkbookFactory.create(fis);
	            Sheet sheet = workbook.getSheetAt(0);

	            // Iterate through all rows (starting from index 1 to skip the header)
	            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
	                Row row = sheet.getRow(rowIndex);

	                if (row != null) {
	                    // Read column K (index 10)
	                    Cell colKCell = row.getCell(10);

	                    if (colKCell != null) {
	                        String colKValue = colKCell.toString().trim();

	                        // Read column C (index 2)
	                        Cell colCCell = row.getCell(2);

	                        if (colCCell != null && colCCell.getCellType() == CellType.NUMERIC) {
	                            int colCValue = (int) colCCell.getNumericCellValue();

	                            // Initialize the expected value for this column K group if not already set
	                            if (!expectedValuesMap.containsKey(colKValue)) {
	                                expectedValuesMap.put(colKValue, colCValue);
	                            }

	                            int expectedValue = expectedValuesMap.get(colKValue);

	                            // Check if the current value in column C matches the expected value
	                            if (colCValue != expectedValue) {
	                                // If no existing list, create one and add the error message
	                                List<String> errorList = errorsMap.get(colKValue);
	                                if (errorList == null) {
	                                    errorList = new ArrayList<>();
	                                    errorsMap.put(colKValue, errorList);
	                                }
	                                errorList.add("Row " + (rowIndex + 1) + " is not in consecutive order. Expected: " 
	                                              + expectedValue + " but got: " + colCValue);
	                            }

	                            // Update expected value for the next row with the same column K value
	                            expectedValuesMap.put(colKValue, colCValue + 1);
	                        } else {
	                            // If column C is empty or not numeric
	                            List<String> errorList = errorsMap.get(colKValue);
	                            if (errorList == null) {
	                                errorList = new ArrayList<>();
	                                errorsMap.put(colKValue, errorList);
	                            }
	                            errorList.add("Row " + (rowIndex + 1) + " in column C is empty or not numeric.");
	                        }
	                    }
	                }
	            }
	        } finally {
	            if (fis != null) {
	                fis.close();
	            }
	        }

	        return errorsMap;
	    }
}
