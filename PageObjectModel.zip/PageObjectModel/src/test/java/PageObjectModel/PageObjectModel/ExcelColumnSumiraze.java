package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ExcelColumnSumiraze {

	  private String filePath;
	  
	  public ExcelColumnSumiraze(String filePath) {
	        this.filePath = filePath;
	    }

	    public Map<String, Boolean> processExcelData() throws IOException {
	        FileInputStream fis = new FileInputStream(new File(filePath));
	        Workbook workbook = new XSSFWorkbook(fis);
	        Sheet sheet = workbook.getSheetAt(0);

	        Map<String, Double> sumD = new HashMap<>(); // Column D: Indemnity reserve
	        Map<String, Double> sumF = new HashMap<>(); // Column F: Indemnity extra reserve
	        Map<String, Double> valueE = new HashMap<>(); // Column E: Indemnity reserve subtraction
	        Map<String, Double> expectedTotalG = new HashMap<>(); // Column G: Expected total
	        Map<String, Boolean> results = new HashMap<>();

	        for (Row row : sheet) {
	            if (row.getRowNum() == 0) continue; // Skip header row

	            String key = "Row " + row.getRowNum(); // Unique key for each row
	            double d = getCellValueAsDouble(row.getCell(3)); // Column D
	            double f = getCellValueAsDouble(row.getCell(5)); // Column F
	            double e = getCellValueAsDouble(row.getCell(4)); // Column E
	            double g = getCellValueAsDouble(row.getCell(6)); // Column G (Expected total)

	            sumD.put(key, d);
	            sumF.put(key, f);
	            valueE.put(key, e);
	            expectedTotalG.put(key, g);
	        }

	        for (String key : sumD.keySet()) {
	            double calculatedValue = (sumD.get(key) + sumF.get(key)) - valueE.get(key);
	            double expectedValue = expectedTotalG.get(key);
	            
	            // Debugging prints
	            System.out.println("Checking " + key);
	            System.out.println("  Indemnity reserve (D): " + sumD.get(key));
	            System.out.println("  Indemnity extra reserve (F): " + sumF.get(key));
	            System.out.println("  Indemnity reserve subtraction (E): " + valueE.get(key));
	            System.out.println("  Expected Total (G): " + expectedValue);
	            System.out.println("  Calculated Total: " + calculatedValue);

	            // Check with precision tolerance
	            boolean isMatching = Math.abs(calculatedValue - expectedValue) < 0.001;
	            results.put(key, isMatching);
	        }

	        workbook.close();
	        return results; // Returns PASS/FAIL for each row
	    }

	    // Helper method to handle different cell types
	    private double getCellValueAsDouble(Cell cell) {
	        if (cell == null) return 0.0; // Handle empty cells
	        if (cell.getCellType() == CellType.NUMERIC) {
	            return cell.getNumericCellValue();
	        } else if (cell.getCellType() == CellType.STRING) {
	            try {
	                return Double.parseDouble(cell.getStringCellValue().trim());
	            } catch (NumberFormatException e) {
	                return 0.0; // Handle invalid data
	            }
	        }
	        return 0.0; // Default case
	    }
	}

