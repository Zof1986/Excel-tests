package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ExcelNULLValues {

	 public boolean checkForNullValues(String filePath) throws IOException {
	        boolean hasNullValues = false;
	        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
	            Workbook workbook = WorkbookFactory.create(fis);

	            // Loop through all sheets in the workbook
	            for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
	                Sheet sheet = workbook.getSheetAt(sheetIndex);
	                System.out.println("Checking sheet: " + sheet.getSheetName());

	                // Iterate through all rows in the sheet
	                for (Row row : sheet) {
	                    // Iterate through all cells in the row
	                    for (Cell cell : row) {
	                        if (isCellNullOrEmpty(cell)) {
	                            hasNullValues = true;
	                            System.out.println("NULL or empty value found at Sheet: " 
	                                    + sheet.getSheetName() + ", Row: " 
	                                    + (row.getRowNum() + 1) + ", Column: " 
	                                    + (cell.getColumnIndex() + 1));
	                        }
	                    }
	                }
	            }
	            workbook.close();
	        }
	        return hasNullValues;
	    }

	    // Helper method to check if a cell is NULL or empty
	    private static boolean isCellNullOrEmpty(Cell cell) {
	        if (cell == null) {
	            return true; // Cell is NULL
	        }

	        // Check for empty or blank content
	        switch (cell.getCellType()) {
	            case STRING:
	                return cell.getStringCellValue().trim().isEmpty();
	            case BLANK:
	                return true;
	            case NUMERIC:
	            case BOOLEAN:
	            case FORMULA:
	                return false; // Valid, not NULL or empty
	            default:
	                return true;
	        }
	    }
	}

