package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class ExcelColumnCColumnB {

	private List<List<String>> data = new ArrayList<>();

    public  ExcelColumnCColumnB(String filePath, String sheetName) throws IOException {
        loadExcelData(filePath, sheetName);
    }

    private void loadExcelData(String filePath, String sheetName) throws IOException {
        FileInputStream file = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(file);
        Sheet sheet = workbook.getSheet(sheetName);

        for (Row row : sheet) {
            List<String> rowData = new ArrayList<>();
            for (Cell cell : row) {
                rowData.add(cell.toString().trim());
            }
            data.add(rowData);
        }

        workbook.close();
        file.close();
    }

    public boolean validateColumnCUnique() {
        Set<String> columnCValues = new HashSet<>();
        for (int i = 1; i < data.size(); i++) { // Skip header
            String columnCValue = data.get(i).get(2); // Column C (Index 2)
            if (!columnCValues.add(columnCValue)) {
                System.out.println(" Duplicate in Column C: " + columnCValue);
                return false;
            }
        }
        return true;
    }

    public boolean validateColumnBtoCMapping() {
        Map<String, String> mapping = new HashMap<>();
        for (int i = 1; i < data.size(); i++) { // Skip header
            String columnBValue = data.get(i).get(1); // Column B (Index 1)
            String columnCValue = data.get(i).get(2); // Column C (Index 2)

            if (mapping.containsKey(columnBValue)) {
                if (mapping.get(columnBValue).equals(columnCValue)) {
                    System.out.println(" Column B value '" + columnBValue + "' has the same Column C value '" + columnCValue + "' as before.");
                    return false;
                }
            }
            mapping.put(columnBValue, columnCValue);
        }
        return true;
    }
    
    public boolean validateColumnAValuesForColumnB() {
        for (int i = 1; i < data.size(); i++) { // Skip header
            String columnAValue = data.get(i).get(0); // Column A (Index 0)
            String columnBValue = data.get(i).get(1); // Column B (Index 1)

            if (!columnAValue.equalsIgnoreCase("O") && !columnAValue.equalsIgnoreCase("C")) {
                System.out.println(" Column B value '" + columnBValue + "' has invalid Column A value: '" + columnAValue + "' (Expected 'O' or 'C').");
                return false;
            }
        }
        return true;
    }
    
    
}

