package PageObjectModel.PageObjectModel;

import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExcelHardcodedData {
	
	private String filePath;

    // Constructor to initialize file path
    public ExcelHardcodedData(String filePath) {
        this.filePath = filePath;
    }

    // Method to validate the transaction sheet
    public List<String> validateTransactionSheet() throws IOException {
        List<String> errors = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                String valueJ = getCellValue(row, 9); // Column J
                String valueK = getCellValue(row, 10); // Column K

                if (valueK != null && !valueK.isEmpty()) { // If column K has a value
                    if (!"test".equalsIgnoreCase(valueJ)) { // Check if column J contains "test"
                        errors.add("Row " + (row.getRowNum() + 1) + ": Column J must have value 'test' when Column K has a value.");
                    }
                }
            }
        }
        return errors;
    }

    // Helper method to get a cell value
    private String getCellValue(Row row, int columnIndex) {
        Cell cell = row.getCell(columnIndex);
        return cell != null ? cell.toString().trim() : null;
    }

}
